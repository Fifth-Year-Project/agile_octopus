import requests
import traceback

import lumen
try:
    #AGILE-OUTGOING-19-05-13
    #
    BASE_URL = "https://api.octopus.energy"
    PRODUCT_CODE = "AGILE-18-02-21" # This is the product code for ocotpus agile
    PRODUCT_CODE = "AGILE-FLEX-22-11-25"
    TARIFF_CODE = f"E-1R-{PRODUCT_CODE}-N" # The letter N specifies the south scotland region
    TARIFF_URL = f"{BASE_URL}/v1/products/{PRODUCT_CODE}/electricity-tariffs/{TARIFF_CODE}/standard-unit-rates/"
    r = requests.get(TARIFF_URL)
    octopus_import_prices = r.json()["results"]
    import_prices = {}
    for time_period in octopus_import_prices:
        import_prices[time_period["valid_from"]] = time_period["value_inc_vat"]

    PRODUCT_CODE = "AGILE-OUTGOING-19-05-13"
    TARIFF_CODE = f"E-1R-{PRODUCT_CODE}-N" # The letter N specifies the south scotland region
    TARIFF_URL = f"{BASE_URL}/v1/products/{PRODUCT_CODE}/electricity-tariffs/{TARIFF_CODE}/standard-unit-rates/"
    r = requests.get(TARIFF_URL)
    octopus_export_prices = r.json()["results"]
    export_prices = {}
    for time_period in octopus_export_prices:
        export_prices[time_period["valid_from"]] = time_period["value_inc_vat"]
    
    results = {"import_prices": import_prices, "export_prices" : export_prices}
    lumen.save(results)
except:
    lumen.save_exception(traceback.format_exc())